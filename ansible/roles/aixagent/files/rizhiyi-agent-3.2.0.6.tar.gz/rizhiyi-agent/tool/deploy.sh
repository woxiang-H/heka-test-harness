#!/bin/sh
if [ $# == 4 ]; then
    IP_INFO=$1
    FRONTEND_ADDR=$2
    TOKEN=$3
    COLLECTOR_ADDR=$4
else
    echo "USAGE:$0 ip_info.txt frontend_ip:frontend_port token collector_ip:collector_port"
    exit -1
fi

if ! [ -f ${IP_INFO} ]; then
    echo "${IP_INFO} not exists"
    exit -1
fi

cat ${IP_INFO} | while read line
do
    INFO_ITEMS=($line)
    LEN=${#INFO_ITEMS[@]}
    if [ $LEN -lt 5 ]; then
        echo "Line is invliad: $line"
        echo "Should be \"IP PORT USER PASSWD DIR [JAVA_BIN]\""
        exit -1
    fi
    IP=${INFO_ITEMS[0]}
    PORT=${INFO_ITEMS[1]}
    USER=${INFO_ITEMS[2]}
    PASSWD=${INFO_ITEMS[3]}
    DIR=${INFO_ITEMS[4]}
    JAVA_BIN=${INFO_ITEMS[5]}

    # Create dir
    expect -c "
       spawn ssh $USER@$IP \"rm -rf $DIR/rizhiyi-agent;mkdir -p $DIR/rizhiyi-agent/log;mkdir -p $DIR/rizhiyi-agent/backup;mkdir -p $DIR/rizhiyi-agent/log\"
       set timeout 5
       expect yes/no { send yes\r ; exp_continue }
       expect assword: { send $PASSWD\r ; exp_continue }
       exit
    "
    echo "Create dir at ${IP} success"

    # Transfer bin to remote
    expect -c "
       spawn scp -rp ../bin $USER@$IP:$DIR/rizhiyi-agent/
       set timeout 5
       expect yes/no { send yes\r ; exp_continue }
       set timeout -1
       expect assword: { send $PASSWD\r ; exp_continue }
       exit
    "
    echo "Transfer bin to ${IP} success"

    # Transfer conf to remote
    expect -c "
       spawn scp -rp ../conf $USER@$IP:$DIR/rizhiyi-agent/
       set timeout 5
       expect yes/no { send yes\r ; exp_continue }
       set timeout -1
       expect assword: { send $PASSWD\r ; exp_continue }
       exit
    "
    echo "Transfer conf to ${IP} success"

    # Init config & start process
    expect -c "
       set timeout 5
       spawn ssh $USER@$IP \"cd $DIR/rizhiyi-agent/bin;/bin/ksh install.ksh $IP:$PORT $FRONTEND_ADDR $TOKEN $COLLECTOR_ADDR $JAVA_BIN\"
       expect yes/no { send yes\r ; exp_continue }
       expect assword: { send $PASSWD\r ; exp_continue }
       sleep 1
       exit
    "
    echo "Init config & start rizhiyi-agent at ${IP} success"
done
