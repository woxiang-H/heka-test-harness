脚本会输出两份：一份存到/opt/RZY/unix_scripts/javagc/javagc.log, 一份直接输出到stdout, 所以用crontab跑然后heka采集javagc.log也可以，用heka采集直接调用这个脚本也是可以的。

脚本执行参数：<PATH>/javagc.sh -j jstat_path -t time_interval -c count -p processname ...
比如/tmp/javagc.sh -j /opt/rizhiyi/java/bin/jstat -t 1000 -c 3 -p yottasearch collector frontend
其中-j 后面带jstat文件绝对路径，如果写的不是/jstat结尾就会用默认的/opt/rizhiyi/java/bin/jstat作为值，如果连默认的/opt/rizhiyi/java/bin/jstat都不存在，则脚本退出；-t 后面带时间间隔值，单位为毫秒，如果小于1000，则此值不生效，程序退出； -c 后面带次数值，即一个进程输出多少行的值，如果这个值大于60， 则此值不生效，程序退出。 当time_interval 或者 count只有一个有合法的值，则只输出一次。time_interval*count 不能大于1分钟。
只有-p参数是必须的。