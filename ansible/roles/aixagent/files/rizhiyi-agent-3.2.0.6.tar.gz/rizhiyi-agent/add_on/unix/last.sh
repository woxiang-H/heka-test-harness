#!/bin/sh

BASEDIR=$(dirname $0)
VARDIR=${BASEDIR}/var
[ -d ${VARDIR} ] || { mkdir -p ${VARDIR}; }

LASTFILE=${VARDIR}/last.out
TEMPFILE=${VARDIR}/last.tmp
NUM=${1:-100}

touch ${LASTFILE}

last -n $NUM | egrep -v "^$|^wtmp begins|still logged in|^\<reboot\>|^reboot|^shutdown" | sort > ${TEMPFILE}

comm -13 ${LASTFILE} ${TEMPFILE}

cp ${TEMPFILE} ${LASTFILE}
