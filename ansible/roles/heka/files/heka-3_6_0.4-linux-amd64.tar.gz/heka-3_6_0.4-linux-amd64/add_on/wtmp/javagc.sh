#!/bin/bash

BASEDIR=/opt/RZY/unix_scripts/javagc
FILENAME=${BASEDIR}/javagc.log
THRESHOLDSIZE=100000000



[[ ! -d ${BASEDIR} ]] && mkdir -p ${BASEDIR}
if [[ ! -d ${BASEDIR} ]];then
  echo "Error: directory ${BASEDIR} creation failed!"
  exit
fi

fileIfExists() {
if [[ ! -f $1 ]];then
  touch $1
fi
}

getFileSize() {
FILESIZE=`ls -l $1 | awk '{print $5}'`
}



fileIfExists ${FILENAME}


getFileSize ${FILENAME}
if [[ ${FILESIZE} -gt ${THRESHOLDSIZE} ]];then
  echo > ${FILENAME}
fi



Usage() {
echo -e "\033[1;31mUsage:\n`basename $0` -j jstat_path -t time_interval(ms) -c count -p processname1 processname2 ...\n\nImportant: 1. Only -p processname1 is mandatory. If jstat_path not specified, use /opt/rizhiyi/java/bin/jstat instead; if time_interval and count not specified, then only print out 1 record for the processname. 2. time_interval*count must not be bigger than 60000(1 minute)\033[m"
exit
}



while [ "$1" != "" ]; do
  case $1 in
    -t ) shift
     time_interval=$1
     ;;
    -c ) shift
     count=$1
     ;;
    -p | --process) shift
     if [[ $2 != "-t" ]] || [[ $2 != "-c" ]] || [[ $2 != "-j" ]];then
       PROCESSES="$@"
     else
       PROCESSES="$1"
     fi
     ;;
    -j ) shift
     JAVAPATH=$1
     ;;
    -h | --help )
    Usage;;
  esac
  shift
done

if [[ "x${PROCESSES}" == "x" ]] || ( [[ -n ${time_interval} ]] && [[ ${time_interval} -lt 1000 ]] ) || ( [[ -n ${count} ]] && [[ ${count} -gt 60 ]]) || ( [[ -n ${time_interval} ]] && [[ -n ${count} ]] && let total=time_interval*count && [[ $total > 60000 ]]); then
  Usage
fi
if [[ "x${JAVAPATH}" == "x" ]]; then
    echo "JAVAPATH does not specify, use default setting: /opt/rizhiyi/java/bin/jstat"
    JAVAPATH=/opt/rizhiyi/java/bin/jstat
elif [[ ! ${JAVAPATH} =~ /jstat$ ]]; then
    echo "${JAVAPATH} not legal, use default setting: /opt/rizhiyi/java/bin/jstat"
    JAVAPATH=/opt/rizhiyi/java/bin/jstat
fi
if [[ ! -f ${JAVAPATH} ]];then
    echo "${JAVAPATH} does not exist. Quit!"
    exit
fi
[[ ! -x ${JAVAPATH} ]] && chmod +x ${JAVAPATH}

#echo "time_interval is $time_interval, count is $count, processes are $PROCESSES"
PROCESSARRY=(${PROCESSES})
unsetarry() {
for(( i=0;i<${#PROCESSARRY[@]};i++))
do
if [[ ${PROCESSARRY[i]} == "-t" ]];then
    a=$i
    let b=i+1
fi
if [[ ${PROCESSARRY[i]} == "-c" ]];then
    c=$i
    let d=c+1
fi
if [[ ${PROCESSARRY[i]} == "-j" ]];then
    e=$i
    let f=e+1
fi
done

for j in "$a" "$b" "$c" "$d" "$e" "$f"
do
    if [[ -n $j ]];then
        unset PROCESSARRY[$j]
    fi
done
}

unsetarry

for i in "${PROCESSARRY[@]}"
do
    PROCESSNAME=$i
    #ps -ef |grep ${PROCESSNAME} | grep -v ${0} | grep -v "awk -v processname" | grep -v grep
    PROCESSPID=`ps -ef |grep ${PROCESSNAME} | grep -v ${0} | grep -v "awk -v processname" | grep -v grep | awk '{print $2}' | head -n 1`
    if [[ -n ${PROCESSPID} ]];then
            if [[ -n ${time_interval} ]] && [[ -n ${count} ]];then
        ${JAVAPATH} -gcutil ${PROCESSPID} ${time_interval} ${count} | awk -v processname=${PROCESSNAME} -v processpid=${PROCESSPID} 'NR>1{fflush();print processname" "processpid" "strftime("%Y-%m-%d %T")" "$0}' | tee -a ${FILENAME} &
            else
               ${JAVAPATH} -gcutil ${PROCESSPID} | awk -v processname=${PROCESSNAME} -v processpid=${PROCESSPID} 'NR>1{fflush();print processname" "processpid" "strftime("%Y-%m-%d %T")" "$0}' | tee -a ${FILENAME} &
            fi
    else
        echo "${PROCESSNAME} does not find pid."
    fi
done
wait

