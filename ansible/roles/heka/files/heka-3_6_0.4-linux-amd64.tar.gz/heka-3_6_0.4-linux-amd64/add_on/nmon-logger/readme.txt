采集*.nmon文件相关脚本，使用说明:
1.确保机器上已有nmon运行
  假设生成的*.nmon在$/var/nmon/repo目录下，则执行
/bin/sh ${INSTALL_DIR}/add_on/nmon-logger/bin/nmon.sh /var/nmon/repo
2.建议执行频率为60秒，以\n换行