#!/bin/sh

BASEDIR=$(dirname $0)
VARDIR=${BASEDIR}/var
[ -d ${VARDIR} ] || { mkdir -p ${VARDIR}; }

LASTFILE=${VARDIR}/history.out
TEMPFILE=${VARDIR}/history.tmp

touch ${LASTFILE}

history  > ${TEMPFILE}

comm -13 ${LASTFILE} ${TEMPFILE}

cp ${TEMPFILE} ${LASTFILE}
