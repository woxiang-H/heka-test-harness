#!/bin/sh

BASEDIR=$(dirname $0)
VARDIR=${BASEDIR}/var
[ -d ${VARDIR} ] || { mkdir -p ${VARDIR}; }

LASTFILE=${VARDIR}/audit.out
TEMPFILE=${VARDIR}/audit.tmp

touch ${LASTFILE}

auditpr -v < /auditlog/trail | sort > ${TEMPFILE}

comm -13 ${LASTFILE} ${TEMPFILE}

cp ${TEMPFILE} ${LASTFILE}
