采集wtmp日志相关脚本，使用说明:
1./bin/sh ${INSTALL_DIR}/add_on/unix/last.sh
2.建议执行频率为60秒，以\n换行