#!/bin/sh

BASEDIR=$(dirname $0)
VARDIR=${BASEDIR}/var
[ -d ${VARDIR} ] || { mkdir -p ${VARDIR}; }

LASTFILE=${VARDIR}/failedlogin.out
TEMPFILE=${VARDIR}/failedlogin.tmp

touch ${LASTFILE}

who /etc/security/failedlogin | sort > ${TEMPFILE}

comm -13 ${LASTFILE} ${TEMPFILE}

cp ${TEMPFILE} ${LASTFILE}
