#!/bin/bash
cd $(dirname $0)
PIDFILE=rsyncd.pid
if [ -f ${PIDFILE} ]; then
  PID=$(/bin/cat $PIDFILE)
  NAME=$(ps -p $PID -o comm=)
  if [ "${NAME}" = "rsync" ]; then
     /bin/kill ${PID}
  fi
fi