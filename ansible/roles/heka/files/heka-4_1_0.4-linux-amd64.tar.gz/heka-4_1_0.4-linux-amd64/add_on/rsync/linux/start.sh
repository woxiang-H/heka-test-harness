#!/bin/bash
cd $(dirname $0)
PIDFILE=rsyncd.pid
if [ -f ${PIDFILE} ]; then
  PID=$(/bin/cat $PIDFILE)
  NAME=$(ps -p $PID -o comm=)
  if [ "${NAME}" != "rsync" ]; then
     /bin/rm ${PIDFILE}
  fi
fi
whoami=$(whoami)
chmod 600 rsyncd.conf
chown ${whoami}:${whoami} rsyncd.conf
rsync --daemon --config=rsyncd.conf
