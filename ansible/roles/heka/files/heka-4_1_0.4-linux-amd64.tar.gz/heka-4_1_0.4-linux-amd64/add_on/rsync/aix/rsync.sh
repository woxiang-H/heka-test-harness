#!/usr/bin/ksh
if [ "$#" -lt 2 ]
then
echo "Usage:  $0 remote_addr(ip:port) local_ip(ip)"
exit 1
fi
rsynchome=$(cd $(dirname $0); pwd)
localhostname=`uname`
localip=$2
cd $rsynchome
chmod 600 pass
whoami=$(whoami)
chown ${whoami} pass
dirbydate=`perl -MPOSIX=strftime -le 'print strftime("%Y%m%d", localtime(time()-2*60))'`
echo $dirbydate
find /cbodlog/$dirbydate/log -mmin -60 -name *.cbodlog > filelist.txt
export LIBPATH=$rsynchome
chmod +x ./rsync
./rsync -avR --password-file=pass --contimeout=30 --files-from=filelist.txt / rsync://yottabyte@$1/logs/$localip@$localhostname
