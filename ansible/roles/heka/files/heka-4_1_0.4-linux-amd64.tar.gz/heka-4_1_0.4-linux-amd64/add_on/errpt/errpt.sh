#!/bin/sh

BDIR=$(dirname $0)
iam=`basename $0`
VARDIR=$BDIR/var
PIDFILE=$VARDIR/$iam.pid
#echo "PIDFILE IS: $PIDFILE"
[ -d ${VARDIR} ] || { mkdir -p ${VARDIR}; }
ERRPTLOG=${VARDIR}/rzy_errpt.log
LASTRUN=${VARDIR}/rzy_errpt_lastrun
SHLOG=${VARDIR}/sh.log

nice_stop()
{
	for pid in `ps -ef|grep -v grep|awk '/rzy_errpt/ {print $2}'`
	do
        	echo "Cleaning up old errpt processes: killing $pid" >> ${SHLOG}
        	/usr/bin/kill -9 $pid > /dev/null 2>&1
	done
        [ -f $PIDFILE ] && { rm $PIDFILE; }
        date +%m%d%H%M%y > $LASTRUN
        exit 0
}

trap "nice_stop" INT TERM SIGHUP SIGINT SIGTERM

watch()
{
        echo "Refreshing PIDFILE" >> ${SHLOG}
        echo $$ > $PIDFILE
        echo "Setting lastrun" >> ${SHLOG}
        [ -f $LASTRUN ] && { lastrun=`cat $LASTRUN`; } || { lastrun=`date +%m%d%H%M%y`; }
	
	# Test to see if rzy_errpt link exists, else create it
	[ -h $BDIR/rzy_errpt ] || { ln -s /usr/bin/errpt $BDIR/rzy_errpt; }
        echo "starting $BDIR/rzy_errpt -a -s $lastrun > $ERRPTLOG" >> ${SHLOG}
        $BDIR/rzy_errpt -a -s $lastrun >> $ERRPTLOG
        date +%m%d%H%M%y > $LASTRUN
        cat ${ERRPTLOG}
        rm ${ERRPTLOG}
        nice_stop

}

if [ ! -f $LASTRUN ];then
        echo 0101010010 > $LASTRUN
fi

rm ${SHLOG}

if [ -f $PIDFILE ];then
        OLDPID=`cat $PIDFILE`
        if [ `ps -ef|grep -v grep|grep -c $OLDPID` -gt 0 ] || [ `ps -ef|grep -v grep |grep -c "errpt.sh"` -gt 1 ]; then
                echo "$iam Still running" >> ${SHLOG}
		exit 1
        else
                [ -f $PIDFILE ] && { rm $PIDFILE; }
		
		# cron task tends to kill scripts with a -9 so errpt doesn't get whacked
		# Now I'm going to kill any remaining
		for pid in `ps -ef|grep -v grep|awk '/rzy_errpt/ {print $2}'`
		do
        		echo "Cleaning up old errpt processes: killing $pid" >> ${SHLOG}
        		/usr/bin/kill -9 $pid
		done

                watch
        fi
elif [ `ps -ef|grep -v grep|grep -c rzy_errpt` -gt 0 ]; then	
        for pid in `ps -ef|grep -v grep|awk '/rzy_errpt/ {print $2}'`
        do
                echo "Cleaning up old errpt processes: killing $pid" >> ${SHLOG}
                /usr/bin/kill -9 $pid
        done	
else        
        watch
fi